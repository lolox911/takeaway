import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/app/lib/actions'

export function middleware(req: NextRequest) {
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|.*\\.png$).*)'],
};