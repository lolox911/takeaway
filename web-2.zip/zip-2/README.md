# La bêta du Starhack

Vos grands frères d'hackademint ont fait plusieurs tentatives (infructueuse) pour la page web du starhack. Tentez d'en percer les mystères !

## Version 0.01

- Tentative d'ajout d'un système de points. Il est sécurisé et permettrait le bon fonctionnement du jeu.

## Version 0.12

- Score enlevé pour maintenance.
- Ajout d'un système d'authentification hautement sécurisé.

------------

Pour lancer :

docker-compose up --build

Pour installer docker compose :

Internet est votre ami :D

