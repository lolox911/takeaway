import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center mt-[-20%]">
        <h1 className="text-4xl font-bold">Page en construction</h1>
        <p className="text-xl mt-4 mb-5">C&#39;est pour ça que c&#39;est en bêta</p>
        <Link href="/" className="text-blue-500 hover:text-blue-700 text-xl">Retour à l&#39;accueil</Link>
      </div>
    </div>
  );
}
