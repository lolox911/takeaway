import Image from 'next/image';

export default function Home() {
  return (
      <div className="flex items-center justify-center h-screen">
          <div className="text-center">
              <h1 className="text-4xl font-bold">Bienvenue sur le Starhackademint !</h1>
              <p className="text-xl mt-4">Vous allez voir, ça va être chouette etc</p>
              <div className="flex justify-center mt-4">
                <Image 
                  src="/gorfou.jpeg"
                  width="500"
                  height="500"
                  alt="gorfou doré"
                />
              </div>
          </div>
      </div>
  )
}
