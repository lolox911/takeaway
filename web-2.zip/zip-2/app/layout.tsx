import type { Metadata } from "next";
import { montserrat } from '@/app/ui/fonts';
import "@/app/ui/globals.css";
import Navbar from "@/app/ui/navbar";
import { getSession } from '@/app/lib/actions';
import { JwtPayload } from 'jsonwebtoken';

export const metadata: Metadata = {
  title: "Starhackademint2024 - bêta",
  description: "C'est la bêta wsh",
  icons: {
    icon: "null",
  }
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const user = await getSession();
  const username = user ? (user as JwtPayload).username : null;

  return (
    <html lang="fr">
      <body className={montserrat.className}>
        <Navbar user={username} />
        {children}
      </body>
    </html>
  );
}