'use server'

import jwt from 'jsonwebtoken'
import pool from '@/app/lib/db'
import { cookies } from 'next/headers'

// Penser à remplacer par un secret très protégé !!!
const SECRET_KEY = 'fake_secret'

export async function authenticate(_currentState: unknown, { username, password }: { username: string; password: string }) {
  try {
    const { rows } = await pool.query('SELECT * FROM users WHERE username = $1 AND password = $2', [username, password])
    if (rows.length > 0) {
      const token = await signIn(username) 
      cookies().set('access_token', token, { httpOnly: true, sameSite: 'lax' })
      return { message: 'Authenticated successfully.', token }
    } else {
      return { message: 'Invalid credentials.', token: null }
    }
  } catch (error) {
    console.error('Authentication error:', error)
    return { message: 'Something went wrong.', token: null }
  }
}

export async function signIn(username: string) {
  const payload = {
    username,
    admin: false // Penser à ajouter la condition if...
  }

  const token = jwt.sign(payload, SECRET_KEY, { expiresIn: '24h' }) 

  return token
}

export async function getSession() {
  const accessTokenCookie = cookies()?.get('access_token');
  const access_token = accessTokenCookie ? accessTokenCookie.value : '';

  if (!access_token) {
    return null;
  }

  try {
    const currentUser = jwt.verify(access_token, SECRET_KEY);
    return currentUser;
  } catch (error) {
    console.error('Token verification error:', error);
    return null;
  }
}

export async function inscription({ username, password }: { username: string; password: string }) {
  try {
    const { rows } = await pool.query('SELECT * FROM users WHERE username = $1', [username])
    if (rows.length > 0) {
      return { message: 'Username already exists.', success: false }
    }

    await pool.query('INSERT INTO users (username, password) VALUES ($1, $2)', [username, password])
    return { message: 'User registered successfully.', success: true }
  } catch (error) {
    console.error('Registration error:', error)
    return { message: 'Something went wrong.', success: false }
  }
}