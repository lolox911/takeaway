import { getSession } from '@/app/lib/actions'
import { JwtPayload } from 'jsonwebtoken'

export default async function Profil() {
    const currentUser = await getSession()
    const username = (currentUser as JwtPayload)?.username
    const isAdmin = (currentUser as JwtPayload)?.admin

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-100">
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
                {isAdmin ? (
                    <>
                        <h1 className="text-2xl font-bold mb-4">Admin Profil</h1>
                        <p className="text-lg">Flag: {process.env.FLAG}</p>
                    </>
                ) : username ? (
                    <>
                        <h1 className="text-2xl font-bold mb-4">User Profil</h1>
                        <p className="text-lg">Username: {username}</p>
                    </>
                ) : (
                    <p className="text-lg">????????????????????????????????????? tricheur</p>
                )}
            </div>
        </div>
    )
}