import Link from 'next/link'
import { getSession } from '@/app/lib/actions'
import { JwtPayload } from 'jsonwebtoken'
import { isDynamicServerError } from "next/dist/client/components/hooks-server-context";
import { GetServerSideProps } from 'next'

type NavbarProps = {
  user: string | null
}

export default function Navbar({ user }: NavbarProps) {
  return (
    <nav className="bg-gray-800 p-4">
      <div className="container mx-auto flex justify-between items-center">
        <div className="text-white text-2xl font-bold">
          Starhackademint (v0.12)
        </div>
        <div className="space-x-4 flex items-center">
          <Link href="/" className="text-gray-300 hover:text-white">Accueil</Link>
          <Link href="/challenges" className="text-gray-300 hover:text-white">Challenges</Link>
          {user ? (
            <Link href="/profil" className="text-gray-300 hover:text-white">Profil</Link>
          ) : (
            <>
              <Link href="/inscription" className="text-gray-300 hover:text-white">Inscription</Link>
              <Link href="/connexion" className="text-gray-300 hover:text-white">Connexion</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  )
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  try {
    const user = await getSession()
    if (typeof user === 'string') {
      return { props: { user: null } }
    }
    return { props: { user: user ? (user as JwtPayload).username : null } }
  } catch (error) {
    if (isDynamicServerError(error)) {
      throw error;
    }
    console.error('Error fetching user session:', error)
    return { props: { user: null } }
  }
}