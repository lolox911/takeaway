CREATE TABLE IF NOT EXISTS "users" (
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    PRIMARY KEY (username)
);

INSERT INTO "users" (username, password) VALUES ('admin', 'admin');

GRANT ALL PRIVILEGES ON DATABASE bdd TO ctf_user;
